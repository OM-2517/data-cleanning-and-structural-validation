"""
Task 1 - Data Cleaning & Structural Validation
Reproducible cleaning pipeline for raw_retail_transactions.csv.

Input:
  raw_retail_transactions.csv (synthetic instructional dataset; 985 rows)

Outputs:
  cleaned_retail_transactions.csv
  quarantined_records.csv
  cleaning_log.csv
  validation_results.csv
  cleaning_summary.json
"""

from pathlib import Path
from dateutil import parser
import json
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
RAW_FILE = BASE_DIR / "raw_retail_transactions.csv"

def parse_mixed_date(value):
    """Parse mixed ISO and day-first text dates without silently inventing a date."""
    if value is None or pd.isna(value) or str(value).strip() == "":
        return pd.NaT
    text_value = str(value).strip()
    try:
        # ISO year-first strings must stay year-first; dayfirst applies only
        # to the deliberately mixed slash-formatted dates.
        if len(text_value) >= 10 and text_value[4:5] == "-" and text_value[:4].isdigit():
            return parser.parse(text_value, yearfirst=True, dayfirst=False)
        return parser.parse(text_value, dayfirst=True)
    except (ValueError, TypeError, OverflowError):
        return pd.NaT

def main():
    if not RAW_FILE.exists():
        raise FileNotFoundError(f"Required input file not found: {RAW_FILE}")

    raw = pd.read_csv(RAW_FILE, dtype=str, keep_default_na=False)
    initial_rows = len(raw)

    # 1) Remove exact full-row duplicates before normalizing values.
    exact_duplicate_mask = raw.duplicated(keep="first")
    exact_duplicates_removed = int(exact_duplicate_mask.sum())
    stage = raw.loc[~exact_duplicate_mask].copy()

    # 2) Normalize text and identifiers.
    for col in ["InvoiceNo", "StockCode", "Description", "CustomerID", "Country"]:
        stage[col] = stage[col].astype("string").str.strip()
        stage[col] = stage[col].replace(
            {"": pd.NA, "nan": pd.NA, "None": pd.NA, "NONE": pd.NA}
        )

    stage["InvoiceNo"] = stage["InvoiceNo"].str.upper()
    stage["StockCode"] = stage["StockCode"].str.upper()
    stage["Description"] = (
        stage["Description"].str.replace(r"\s+", " ", regex=True).str.upper()
    )

    country_map = {
        "UK": "United Kingdom",
        "UNITED KINGDOM": "United Kingdom",
        "EIRE": "EIRE",
        "USA": "USA",
        "US": "USA",
        "FRANCE": "France",
        "GERMANY": "Germany",
        "SPAIN": "Spain",
        "NETHERLANDS": "Netherlands",
        "BELGIUM": "Belgium",
        "PORTUGAL": "Portugal",
    }
    stage["Country"] = (
        stage["Country"].str.upper().map(country_map)
        .fillna(stage["Country"].str.title())
    )

    # 3) Parse numbers safely. Currency symbols and separators are normalized.
    stage["Quantity_num"] = pd.to_numeric(
        stage["Quantity"].astype("string").str.strip(), errors="coerce"
    )
    clean_price = (
        stage["UnitPrice"].astype("string")
        .str.replace("£", "", regex=False)
        .str.replace("$", "", regex=False)
        .str.replace(",", "", regex=False)
        .str.strip()
    )
    stage["UnitPrice_num"] = pd.to_numeric(clean_price, errors="coerce")

    # 4) Parse mixed date formats, preserving invalid dates as NaT for review.
    stage["InvoiceDate_parsed"] = stage["InvoiceDate"].apply(parse_mixed_date)

    # 5) Recover blank descriptions only where StockCode has an unambiguous
    #    modal description in the observed data. Do not guess from unrelated rows.
    desc_lookup = (
        stage.dropna(subset=["StockCode", "Description"])
        .groupby("StockCode")["Description"]
        .agg(lambda s: s.mode().iloc[0] if not s.mode().empty else s.iloc[0])
        .to_dict()
    )
    missing_desc_before = int(stage["Description"].isna().sum())
    stage["Description"] = stage.apply(
        lambda r: desc_lookup.get(r["StockCode"], pd.NA)
        if pd.isna(r["Description"]) else r["Description"],
        axis=1,
    )
    descriptions_recovered = (
        missing_desc_before - int(stage["Description"].isna().sum())
    )

    # 6) Quarantine records that cannot safely be treated as valid transaction lines.
    reason_masks = [
        (stage["InvoiceNo"].isna(), "Missing invoice number"),
        (stage["StockCode"].isna(), "Missing stock code"),
        (stage["Quantity_num"].isna(), "Quantity is missing or non-numeric"),
        (stage["Quantity_num"].eq(0), "Zero quantity line"),
        (stage["UnitPrice_num"].isna(), "Unit price is missing or non-numeric"),
        (stage["UnitPrice_num"].lt(0), "Negative unit price"),
        (stage["InvoiceDate_parsed"].isna(), "Invoice date is missing or invalid"),
    ]
    reasons = []
    for row_pos in range(len(stage)):
        row_reasons = [
            label for mask, label in reason_masks if bool(mask.fillna(False).iloc[row_pos])
        ]
        reasons.append("; ".join(row_reasons))
    stage["QuarantineReason"] = reasons

    quarantine_mask = stage["QuarantineReason"].ne("")
    quarantine = stage.loc[
        quarantine_mask,
        ["InvoiceNo", "StockCode", "Description", "Quantity", "InvoiceDate",
         "UnitPrice", "CustomerID", "Country", "QuarantineReason"],
    ].copy()
    accepted = stage.loc[~quarantine_mask].copy()

    # 7) Create canonical typed output. Negative quantities remain valid because
    #    they can represent returns/cancellations. Missing CustomerID/Country
    #    remain missing; they are not safely inferable from the supplied fields.
    accepted["Quantity"] = accepted["Quantity_num"].round().astype("int64")
    accepted["UnitPrice"] = accepted["UnitPrice_num"].astype(float).round(2)
    accepted["InvoiceDate"] = accepted["InvoiceDate_parsed"]
    accepted["LineAmountGBP"] = (
        accepted["Quantity"] * accepted["UnitPrice"]
    ).round(2)

    output_columns = [
        "InvoiceNo", "StockCode", "Description", "Quantity", "InvoiceDate",
        "UnitPrice", "CustomerID", "Country", "LineAmountGBP",
    ]
    cleaned = accepted[output_columns].copy()

    # 8) Remove duplicates that become equivalent after trimming/case/date/number
    #    normalization. The key represents the transaction-line grain.
    line_key = [
        "InvoiceNo", "StockCode", "Description", "Quantity", "InvoiceDate",
        "UnitPrice", "CustomerID", "Country",
    ]
    business_duplicate_mask = cleaned.duplicated(subset=line_key, keep="first")
    business_duplicates_removed = int(business_duplicate_mask.sum())
    cleaned = cleaned.loc[~business_duplicate_mask].copy()

    # Stable, presentation-friendly CSV types.
    cleaned["InvoiceDate"] = cleaned["InvoiceDate"].dt.strftime("%Y-%m-%d %H:%M:%S")
    cleaned.to_csv(BASE_DIR / "cleaned_retail_transactions.csv", index=False)
    quarantine = quarantine.astype(object).where(pd.notna(quarantine), "")
    quarantine.to_csv(BASE_DIR / "quarantined_records.csv", index=False)

    cleaning_log = pd.DataFrame([
        ["Imported raw file", initial_rows, "Initial raw record count"],
        ["Exact duplicate rows removed", exact_duplicates_removed,
         "Exact full-row duplicates removed before transformations"],
        ["Rows after exact duplicate removal", len(stage),
         "Records carried into normalization"],
        ["Descriptions initially missing", missing_desc_before,
         "Blank descriptions after trimming"],
        ["Descriptions recovered", descriptions_recovered,
         "Filled using modal description for the same StockCode"],
        ["Rows quarantined", len(quarantine),
         "Critical field or validity failures; preserved separately"],
        ["Business-key duplicates removed", business_duplicates_removed,
         "Duplicates detected after normalization at transaction-line grain"],
        ["Final accepted rows", len(cleaned), "Rows available for downstream analysis"],
        ["Missing CustomerID in accepted data", int(cleaned["CustomerID"].isna().sum()),
         "Preserved because anonymous purchases can be legitimate"],
        ["Missing Country in accepted data", int(cleaned["Country"].isna().sum()),
         "Preserved because the source value cannot be inferred safely"],
        ["Unresolved Description in accepted data", int(cleaned["Description"].isna().sum()),
         "Retained as missing if no reliable StockCode mapping exists"],
    ], columns=["Cleaning Step", "Count", "Explanation"])
    cleaning_log.to_csv(BASE_DIR / "cleaning_log.csv", index=False)

    # 9) Automated post-cleaning validation.
    check = cleaned.copy()
    check["Quantity"] = pd.to_numeric(check["Quantity"])
    check["UnitPrice"] = pd.to_numeric(check["UnitPrice"])
    check["InvoiceDate"] = pd.to_datetime(check["InvoiceDate"], errors="coerce")
    checks = [
        ("Required invoice number present", check["InvoiceNo"].notna().all(),
         int(check["InvoiceNo"].isna().sum()), "InvoiceNo must be present"),
        ("Required stock code present", check["StockCode"].notna().all(),
         int(check["StockCode"].isna().sum()), "StockCode must be present"),
        ("Quantity numeric and non-zero",
         bool(check["Quantity"].notna().all() and check["Quantity"].ne(0).all()),
         int((check["Quantity"].isna() | check["Quantity"].eq(0)).sum()),
         "Negative quantities are retained for returns/cancellations"),
        ("Unit price numeric and non-negative",
         bool(check["UnitPrice"].notna().all() and check["UnitPrice"].ge(0).all()),
         int((check["UnitPrice"].isna() | check["UnitPrice"].lt(0)).sum()),
         "Invalid and negative unit prices are quarantined"),
        ("Invoice date valid", check["InvoiceDate"].notna().all(),
         int(check["InvoiceDate"].isna().sum()), "Invalid dates are quarantined"),
        ("No exact duplicate rows", check.duplicated().sum() == 0,
         int(check.duplicated().sum()), "No exact duplicates in final accepted data"),
        ("No duplicate transaction-line keys",
         not check.duplicated(subset=line_key).any(),
         int(check.duplicated(subset=line_key).sum()),
         "Line-grain uniqueness check"),
        ("CustomerID missingness treated as optional", True,
         int(check["CustomerID"].isna().sum()),
         "Missing CustomerID values are preserved, not imputed"),
        ("Country missingness treated as optional", True,
         int(check["Country"].isna().sum()),
         "Missing Country values are preserved, not guessed"),
    ]
    validation = pd.DataFrame(
        checks, columns=["Validation Check", "Passed", "Failures / Count",
                         "Rule / Interpretation"]
    )
    validation["Status"] = validation["Passed"].map({True: "PASS", False: "FAIL"})
    validation = validation[
        ["Validation Check", "Status", "Failures / Count", "Rule / Interpretation"]
    ]
    validation.to_csv(BASE_DIR / "validation_results.csv", index=False)

    summary = {
        "dataset_type": "synthetic instructional dataset",
        "raw_rows": initial_rows,
        "raw_columns": 8,
        "exact_duplicates_removed": exact_duplicates_removed,
        "business_key_duplicates_removed": business_duplicates_removed,
        "quarantined_rows": int(len(quarantine)),
        "cleaned_rows": int(len(cleaned)),
        "descriptions_recovered": descriptions_recovered,
        "missing_customer_ids_preserved": int(cleaned["CustomerID"].isna().sum()),
        "missing_countries_preserved": int(cleaned["Country"].isna().sum()),
        "validation_passed": bool((validation["Status"] == "PASS").all()),
    }
    (BASE_DIR / "cleaning_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    print(json.dumps(summary, indent=2))
    if not summary["validation_passed"]:
        raise RuntimeError("One or more post-cleaning validation checks failed.")

if __name__ == "__main__":
    main()
