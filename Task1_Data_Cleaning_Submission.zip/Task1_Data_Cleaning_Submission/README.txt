TASK 1 - DATA CLEANING & STRUCTURAL VALIDATION
================================================

WHAT THIS PACKAGE CONTAINS
--------------------------
Task1_Data_Cleaning_Report.pdf
    Submission-ready report.
Task1_Data_Cleaning_Report.docx
    Editable version of the report.
Task1_Data_Cleaning_Results.xlsx
    Workbook with summary, audit log, validation results, issue profile,
    data dictionary, cleaned data, quarantined records, and a 100-row raw sample.
raw_retail_transactions.csv
    Full original raw input file (985 rows).
cleaned_retail_transactions.csv
    Final accepted dataset (934 rows).
quarantined_records.csv
    22 records held for review, with explicit reasons.
task1_cleaning_pipeline.py
    Reproducible Python cleaning and validation script.
task1_data_cleaning_notebook.ipynb
    Guided notebook to inspect and run the pipeline.
cleaning_log.csv
validation_results.csv
cleaning_summary.json
    Audit and machine-readable run outputs.

IMPORTANT DATASET TRANSPARENCY NOTE
-----------------------------------
No source dataset was attached to the task conversation. To complete a reproducible
demonstration, this package uses a synthetic retail transaction dataset with intentional
duplicates, missing values, inconsistent formats, and invalid values. The fields and
transaction conventions are inspired by the UCI Online Retail schema, but ALL rows in
the included CSV files are synthetic. Do not describe them as real company/customer data.

RESULTS
-------
Raw rows:                         985
Exact duplicate rows removed:     15
Rows quarantined:                  22
Normalized duplicates removed:    14
Final accepted rows:              934
Descriptions recovered:           22
Missing CustomerID preserved:      74
Missing Country preserved:          8
Automated validation:            9/9 PASS

HOW TO RUN LOCALLY
------------------
1. Extract the ZIP archive.
2. Open a terminal in the extracted Task1_Data_Cleaning_Submission folder.
3. Ensure pandas and python-dateutil are installed:
       pip install pandas python-dateutil
4. Run:
       python task1_cleaning_pipeline.py
5. The script regenerates the cleaned CSV, quarantine CSV, cleaning log,
   validation results, and JSON summary in the same folder.

HOW TO RUN IN GOOGLE COLAB
--------------------------
1. Upload and extract the ZIP into the Colab workspace.
2. Open task1_data_cleaning_notebook.ipynb from the extracted project folder.
3. Run the notebook cells from top to bottom.
4. The notebook locates the project folder and invokes the included pipeline.

CLEANING POLICY
---------------
- Exact full-row duplicates are removed.
- Transaction-line duplicates are checked again after normalization.
- Product descriptions are recovered only from a matching StockCode.
- CustomerID and Country are optional and are not guessed or imputed.
- Negative quantities are preserved because they can represent returns/cancellations.
- Critical invalid records are quarantined, not silently discarded.
- The final data is accepted only after all structural validation checks pass.

REFERENCE
---------
Chen, D. (2015). Online Retail [Dataset]. UCI Machine Learning Repository.
https://doi.org/10.24432/C5BW33
The source is used as a schema/convention reference only. The included transaction
records are synthetic.
